from django.apps import AppConfig


class Neo4JConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Neo4j'
